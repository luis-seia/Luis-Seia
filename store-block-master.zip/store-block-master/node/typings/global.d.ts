declare const metrics

type GenericObject = Record<string, any>
